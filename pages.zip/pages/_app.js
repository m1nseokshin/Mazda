import '@/styles/globals.css'
import Navbar from "./navbar"
import Footerbar from "./footerbar"

export default function App({ Component, pageProps }) {

  return(
    <>
      <Navbar />
      <Component {...pageProps}/>
      <Footerbar />
    </>
  )
}