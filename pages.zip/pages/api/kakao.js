import axios from 'axios';

export default async (req, res) => {
  const { code } = req.body;

  try {
    const response = await axios.post('https://kauth.kakao.com/oauth/token', {
      grant_type: 'authorization_code',
      client_id: '${process.env.NEXT_PUBLIC_KAKAO_API_KEY}',
      redirect_uri: 'http://localhost:3000/login',
      code: code,
    });

    res.status(200).json(response.data);
  } catch (error) {
    res.status(400).json({ error: 'Failed to exchange authorization code for access token.' });
  }
};
