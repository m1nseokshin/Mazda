// pages/protected.js
import { useEffect } from 'react';

const ProtectedPage = () => {
  useEffect(() => {
    // 로그인 여부를 확인하는 로직
    const token = localStorage.getItem('token');

    if (!token) {
      // 로그인되지 않았을 경우 리다이렉트 등 처리
      window.location.href = '/login';
    }
  }, []);

  return (
    <div>
      <h1>보호된 페이지</h1>
      <p>이 페이지는 로그인이 필요합니다.</p>
    </div>
  );
};

export default ProtectedPage;
