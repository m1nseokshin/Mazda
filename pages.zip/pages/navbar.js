import Link from "next/link";
import styles from "@/styles/navbar.module.css"

//이미지 파일 임포트
import Image from "next/image"
import Logo from "/public/image/logo.png"
import Search from "/public/image/search.svg"
import Account from "/public/image/account.svg"

export default function navbar(){

    return (
    <nav className={styles.default}>
        <div className={styles.headerbg}></div>
        <div className={styles.headercontainer}>
            <div className={styles.headeritem}>
                <Link href="/"><Image className={styles.logo} src={Logo} alt="MAZDA" priority/></Link>
                <div className={styles.menus}>
                    <Link className={styles.menu} href="/">HOME</Link>
                    <Link className={styles.menu} href="/about">ABOUT</Link>
                    <Link className={styles.menu} href="/innovation">INNOVATION</Link>
                    <Link className={styles.menu} href="/support">SUPPORT</Link>
                </div>
                <div className={styles.icons}>
                    <Link className={styles.search} href="/"><Image src={Search} alt="MAZDA" /></Link>
                    <Link className={styles.account} href="/login"><Image src={Account} alt="MAZDA" /></Link>
                </div>
            </div>
        </div>

    </nav>
    )
    
}

